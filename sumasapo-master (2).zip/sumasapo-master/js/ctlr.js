// JavaScript Document
jQuery(function ($) {
	
  $(document.body).append('<div class="scrollTopButton"><i class="material-icons">arrow_upward</i></div>')
  $('.scrollTopButton').on('click', function() {
      $('html, body').animate({scrollTop: 0}, 'slow');
  });
  $(window).scroll(function() {
      if ($(this).scrollTop() > 600) { $('.scrollTopButton').css('opacity',1); } 
      else { $('.scrollTopButton').css('opacity',0); }
  });

	$('#menubtn').on('click', function() {
	 $(this).toggleClass('active');
	 $('header').toggleClass('open');
	});
	
	// $('#slide').hide();
  $('#slide').prepend('<div class="clickable_area"></div>')

	$('#slide').find('.clickable_area').on('click', function() {
	 $('#slide').removeClass('open');
	});
  $('#slide').find('.trigger').on('click', function(event) {
	 $('#slide').toggleClass('open');
  });
	
	$('.scrlback').on('click', function(e) {
	 $('body, html').animate({ scrollTop: 0 }, 500);
   e.preventDefault();
	});
	
	$('.modalopen01').on('click',function(){
		$('#modal01').addClass('open');
    return false;
  });
  $('#closearea01').on('click',function(){
    $('#modal01').removeClass('open');
  });
	$('.modalopen02').on('click',function(){
		$('#modal02').addClass('open');
    return false;
  });
  $('#closearea02').on('click',function(){
    $('#modal02').removeClass('open');
  });
	$('.modalopen03').on('click',function(){
		$('#modal03').addClass('open');
    return false;
  });
  $('#closearea03').on('click',function(){
    $('#modal03').removeClass('open');
  });
	$('.modalopen04').on('click',function(){
		$('#modal04').addClass('open');
    return false;
  });
  $('#closearea04').on('click',function(){
    $('#modal04').removeClass('open');
  });
	$('.modalopen05').on('click',function(){
		$('#modal05').addClass('open');
    return false;
  });
  $('#closearea05').on('click',function(){
    $('#modal05').removeClass('open');
  });
 
    //swiper 992未満で起動
    var swiper; 
    $(window).on('load resize', function(){
        var w = $(window).width();
        if (w < 992) {
            if (swiper) {
                return;
            } else {
                swiper = new Swiper('.swiper-container', {
                    loop: true,
					autoplay: {
						delay: 2500,
						disableOnInteraction: true,
					},
				    navigation: {
						nextEl: '.swiper-button-next',
						prevEl: '.swiper-button-prev',
					},
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                    },
                });
            }

          $('.linklist').on('click', function() {
            $(this).toggleClass('open');
          });
          $(document).on('click', function(event) {
            if ( !$(event.target).closest('.linklist.open')[0] ) {
              $('.linklist').removeClass('open');
            }
          });

        } else {
            if (swiper) {
                swiper.destroy();
                swiper = undefined;
            }
        } 
    });

    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#slide').css('opacity',1);
        } 
        else {
            $('#slide').css('opacity',0);
        }
    });


});
