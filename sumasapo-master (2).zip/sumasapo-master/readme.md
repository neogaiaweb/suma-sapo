# ご報告・ご質問

- トップページのキャッチコピー「お家の診断してみませんか?」は画像などはめ込み後、文字をSVG化するなどした方が見栄えがいいかもしれません。またご相談ください。
- グローバルメニュー (三本線アイコンをクリックで開くもの) はPCで見た際、レイアウトに余裕があります。項目を追加されたい場合はご相談ください。
- 「初めての方はお読みください」について、Cookieなどを使用して2回目以降の訪問の場合に非表示にすることもできます。ご相談ください。
- フォームまわり、画像まわりは組み込み・運用を行っていく上で微妙なレイアウトずれの可能性があります。調整が難しそうな場合はお気軽にご相談ください。


# 凡例

- [x] 実装が完了したページ
  - 詳細コメントや註記
  - 不足箇所の指摘など
- [ ] 実装がまだのページ
  - 詳細コメントや註記
  - 進捗など

# 各ページ

弊社担当箇所のコーディング、および共通部分の作り込みが完了いたしましたので、いったん納品いたします。組み込みにあたって不明点や調整希望箇所ありましたら、アフターサービスとしてご対応いたしますので、お気軽にご連絡ください。

※ ★印はMINERALコーディング担当箇所

- [x] [index.html](http://sumasapo.mine-ral.com/index.html) トップページ
- [ ] notice/
  - [x] [index.html](http://sumasapo.mine-ral.com/notice/index.html) お知らせ一覧
  - [ ] [detail.html](http://sumasapo.mine-ral.com/notice/detail.html) お知らせ詳細
- [x] inquiry/
  - [x] [index.html](http://sumasapo.mine-ral.com/inquiry/index.html) お問い合わせフォームページ
    - CSSひな型を用意しています
- [ ] application/
  - [ ] [index.html](http://sumasapo.mine-ral.com/application/index.html) サービス申し込みフォームページ
    - CSSひな型を用意しています (inquiry/index.html を参照)
- [x] area/
  - [x] [list.html](http://sumasapo.mine-ral.com/area/list.html) エリア別検索 ★
- [x] questionnaire/
  - [x] [index.html](http://sumasapo.mine-ral.com/questionnaire/index.html) 作業後アンケートのお願い
- [x] viewing/
  - [x] [viewing.html](http://sumasapo.mine-ral.com/viewing/viewing.html) 最近閲覧したサービス ★
- [x] service/
  - [x] [list.html](http://sumasapo.mine-ral.com/service/list.html) サービス一覧 ★
  - [x] [detail.html](http://sumasapo.mine-ral.com/service/detail.html) サービス詳細 ★
- [ ] contents.php/
  - [x] [flow.html](http://sumasapo.mine-ral.com/contents/flow.html) お申し込みの流れ ★
  - [ ] [qa.html](http://sumasapo.mine-ral.com/contents/qa.html) Q&A
  - [x] [voice.html](http://sumasapo.mine-ral.com/contents/voice.html) お客様の声 ★
  - [x] [company.html](http://sumasapo.mine-ral.com/contents/company.html) 運営会社 ★
  - [x] [pp.html](http://sumasapo.mine-ral.com/contents/pp.html) プライバシーポリシー

# その他

- [x] モーダル等JavaScript調整
- [x] イラスト周り
